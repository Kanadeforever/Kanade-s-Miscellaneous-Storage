/* skip_popup.c — 轻量版: MessageBox 拦截 + 纯净日志 */
#include <windows.h>

static HANDLE g_log=INVALID_HANDLE_VALUE;static CRITICAL_SECTION g_cs;
static void log_open(void){InitializeCriticalSection(&g_cs);char b[MAX_PATH];
GetModuleFileNameA(NULL,b,MAX_PATH);char*p=b;for(char*s=b;*s;s++)if(*s=='\\'||*s=='/')p=s;
p[1]='\0';char*e=b;while(*e)e++;*e++='s';*e++='k';*e++='i';*e++='p';*e++='_';*e++='p';
*e++='o';*e++='p';*e++='u';*e++='p';*e++='.';*e++='l';*e++='o';*e++='g';*e='\0';
g_log=CreateFileA(b,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);}
static void log_write(const char*m){if(g_log==INVALID_HANDLE_VALUE)return;EnterCriticalSection(&g_cs);
SYSTEMTIME st;GetLocalTime(&st);char t[32];DWORD w;wsprintfA(t,"[%02d:%02d:%02d.%03d] ",
st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);WriteFile(g_log,t,lstrlenA(t),&w,NULL);int l=0;
while(m[l])l++;WriteFile(g_log,m,l,&w,NULL);WriteFile(g_log,"\r\n",2,&w,NULL);LeaveCriticalSection(&g_cs);}
static void log_close(void){if(g_log!=INVALID_HANDLE_VALUE){CloseHandle(g_log);g_log=INVALID_HANDLE_VALUE;}
DeleteCriticalSection(&g_cs);}

static BOOL hook5(PBYTE t,PBYTE h,PBYTE*r){DWORD o;
*r=VirtualAlloc(NULL,32,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);if(!*r)return FALSE;
VirtualProtect(t,5,PAGE_EXECUTE_READWRITE,&o);for(int i=0;i<5;i++)(*r)[i]=t[i];
(*r)[5]=0xE9;*(DWORD*)((*r)+6)=(DWORD)((t+5)-((*r)+10));t[0]=0xE9;
*(DWORD*)(t+1)=(DWORD)(h-(t+5));VirtualProtect(t,5,o,&o);FlushInstructionCache(GetCurrentProcess(),t,5);return TRUE;}
static PBYTE gf(const char*d,const char*n){HMODULE m=GetModuleHandleA(d);
if(!m)m=LoadLibraryA(d);return m?(PBYTE)GetProcAddress(m,n):NULL;}

/* ============================================================
 * MessageBoxA — 拦截+自动Yes+日志
 * ============================================================ */
typedef int (WINAPI *MB_t)(HWND,LPCSTR,LPCSTR,UINT);
static PBYTE g_mba=NULL, g_mbw=NULL;

/* 匹配 Shift-JIS 字节序列 */
static int match_sjis(const char*h,const unsigned char*needle,int nlen){
    if(!h||!needle||!nlen)return 0;
    while(*h){int i;for(i=0;i<nlen&&h[i]&&(unsigned char)h[i]==needle[i];i++);
    if(i==nlen)return 1;h++;}
    return 0;
}
/* Shift-JIS: エラー = 83 47 83 89 81 5B, データ = 83 66 81 5B 83 5E */
static const unsigned char k_er_sj[] = {0x83,0x47,0x83,0x89,0x81,0x5B};
static const unsigned char k_da_sj[] = {0x83,0x66,0x81,0x5B,0x83,0x5E};

static int g_suppressed = 0; /* 拦截计数 */

static int WINAPI Hook_MBA(HWND hw,LPCSTR t,LPCSTR c,UINT u){
    UINT bt=u&0x0F;
    int is_err = (c && match_sjis(c,k_er_sj,6)) ||
                 (t && match_sjis(t,k_er_sj,6)) ||
                 (t && match_sjis(t,k_da_sj,6));
    if(is_err && (bt==MB_YESNO||bt==MB_YESNOCANCEL||bt==MB_RETRYCANCEL)){
        g_suppressed++;
        char m[100]; wsprintfA(m,"[skip] verification popup #%d suppressed (btns=%d)", g_suppressed, bt);
        log_write(m); return IDYES;
    }
    if(is_err && bt==MB_ABORTRETRYIGNORE){
        g_suppressed++;
        char m[100]; wsprintfA(m,"[skip] verification popup #%d suppressed (btns=%d)", g_suppressed, bt);
        log_write(m); return IDRETRY;
    }
    return ((MB_t)g_mba)(hw,t,c,u);
}

static const WCHAR* wsstr(const WCHAR*h,const WCHAR*n){if(!h||!n||!*n)return NULL;
while(*h){const WCHAR*a=h,*b=n;while(*a&&*b&&*a==*b){a++;b++;}if(!*b)return h;h++;}return NULL;}

static int WINAPI Hook_MBW(HWND hw,LPCWSTR t,LPCWSTR c,UINT u){
    UINT bt=u&0x0F;
    int is_err = (c && wsstr(c,L"エラー")) || (t && wsstr(t,L"エラー"));
    if(is_err && (bt==MB_YESNO||bt==MB_YESNOCANCEL||bt==MB_RETRYCANCEL)){
        g_suppressed++;
        char m[100]; wsprintfA(m,"[skip] verification popup #%d suppressed (wide, btns=%d)", g_suppressed, bt);
        log_write(m); return IDYES;
    }
    if(is_err && bt==MB_ABORTRETRYIGNORE){
        g_suppressed++;
        char m[100]; wsprintfA(m,"[skip] verification popup #%d suppressed (wide, btns=%d)", g_suppressed, bt);
        log_write(m); return IDRETRY;
    }
    return ((MB_t)g_mbw)(hw,t,c,u);
}

/* ============================================================
 * DllMain
 * ============================================================ */
BOOL APIENTRY DllMain(HMODULE h,DWORD r,LPVOID v){
    if(r==DLL_PROCESS_ATTACH){DisableThreadLibraryCalls(h);log_open();
        log_write("[skip_popup] plugin loaded");
        PBYTE ma=gf("user32.dll","MessageBoxA");
        if(ma&&hook5(ma,(PBYTE)Hook_MBA,&g_mba)){log_write("[skip_popup] MessageBoxA hooked");}
        else log_write("[skip_popup] MessageBoxA hook FAILED");
        PBYTE mw=gf("user32.dll","MessageBoxW");
        if(mw&&hook5(mw,(PBYTE)Hook_MBW,&g_mbw)){log_write("[skip_popup] MessageBoxW hooked");}
        else log_write("[skip_popup] MessageBoxW hook FAILED");
        char m[64]; wsprintfA(m,"[skip_popup] intercept count: %d", g_suppressed);
        log_write(m);
    }else if(r==DLL_PROCESS_DETACH){
        char m[64]; wsprintfA(m,"[skip_popup] unloaded, total suppressed: %d", g_suppressed);
        log_write(m);log_close();}
    return TRUE;
}
