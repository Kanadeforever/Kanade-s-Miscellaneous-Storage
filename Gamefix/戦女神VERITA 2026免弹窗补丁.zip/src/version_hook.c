/* version_hook.c — 独立 version.dll: 弹窗屏蔽 + API 转发 (无 windows.h) */
#include <stddef.h>

typedef unsigned long DWORD;typedef unsigned short WORD;typedef int BOOL;
typedef unsigned int UINT;typedef long LONG_PTR;
typedef void *PVOID;typedef const void *LPCVOID;typedef char CHAR;
typedef const CHAR *LPCSTR;typedef wchar_t WCHAR;typedef const WCHAR *LPCWSTR;
typedef CHAR *LPSTR;typedef WCHAR *LPWSTR;typedef DWORD *LPDWORD;typedef WORD *PUINT;
typedef PVOID *LPVOID;typedef PVOID HMODULE;typedef PVOID HANDLE;typedef PVOID FARPROC;
typedef PVOID HWND;typedef PVOID LPSECURITY_ATTRIBUTES;
typedef unsigned char *PBYTE;
typedef struct{WORD y,mo,dw,d,h,m,s,ms;}SYSTEMTIME;
#define WINAPI __stdcall
#define FALSE 0
#define TRUE 1
#define MAX_PATH 260
#define MEM_COMMIT 0x1000
#define MEM_RESERVE 0x2000
#define PAGE_EXECUTE_READWRITE 0x40
#define GENERIC_WRITE 0x40000000
#define FILE_SHARE_READ 1
#define CREATE_ALWAYS 2
#define FILE_ATTRIBUTE_NORMAL 0x80
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
#define IDYES 6
#define IDRETRY 4
#define MB_YESNO 4
#define MB_YESNOCANCEL 3
#define MB_RETRYCANCEL 5
#define MB_ABORTRETRYIGNORE 2

/* kernel32 */
DWORD WINAPI GetSystemDirectoryW(LPWSTR,DWORD);
HMODULE WINAPI LoadLibraryA(LPCSTR);
HMODULE WINAPI LoadLibraryW(LPCWSTR);
FARPROC WINAPI GetProcAddress(HMODULE,LPCSTR);
BOOL WINAPI DisableThreadLibraryCalls(HMODULE);
PVOID WINAPI VirtualAlloc(PVOID,DWORD,DWORD,DWORD);
BOOL WINAPI VirtualProtect(PVOID,DWORD,DWORD,DWORD*);
BOOL WINAPI FlushInstructionCache(HANDLE,PVOID,DWORD);
DWORD WINAPI GetModuleFileNameA(HMODULE,LPSTR,DWORD);
HANDLE WINAPI CreateFileA(LPCSTR,DWORD,DWORD,LPSECURITY_ATTRIBUTES,DWORD,DWORD,HANDLE);
BOOL WINAPI WriteFile(HANDLE,LPCVOID,DWORD,LPDWORD,PVOID);
BOOL WINAPI CloseHandle(HANDLE);
void WINAPI GetLocalTime(SYSTEMTIME*);
HMODULE WINAPI GetModuleHandleA(LPCSTR);
int WINAPI lstrlenA(LPCSTR);
HANDLE WINAPI GetCurrentProcess(void);

/* user32 */
int WINAPI wsprintfA(LPSTR,LPCSTR,...);
int WINAPI MessageBoxA(HWND,LPCSTR,LPCSTR,DWORD);

/* ============================================================
 * 日志
 * ============================================================ */
static HANDLE g_log=INVALID_HANDLE_VALUE;
static void log_write(const char*m){
    if(g_log==INVALID_HANDLE_VALUE)return;
    SYSTEMTIME st;GetLocalTime(&st);DWORD w;
    char t[32];wsprintfA(t,"[%02d:%02d:%02d.%03d] ",st.h,st.m,st.s,st.ms);
    WriteFile(g_log,t,lstrlenA(t),&w,NULL);
    WriteFile(g_log,m,lstrlenA(m),&w,NULL);
    WriteFile(g_log,"\r\n",2,&w,NULL);
}

/* ============================================================
 * 内联 Hook
 * ============================================================ */
static BOOL hook5(PBYTE tgt,PBYTE hook,PBYTE*tr){DWORD old;
    *tr=VirtualAlloc(NULL,32,MEM_COMMIT|MEM_RESERVE,PAGE_EXECUTE_READWRITE);
    if(!*tr)return FALSE;VirtualProtect(tgt,5,PAGE_EXECUTE_READWRITE,&old);
    for(int i=0;i<5;i++)(*tr)[i]=tgt[i];(*tr)[5]=0xE9;
    *(DWORD*)((*tr)+6)=(DWORD)((tgt+5)-((*tr)+10));tgt[0]=0xE9;
    *(DWORD*)(tgt+1)=(DWORD)(hook-(tgt+5));VirtualProtect(tgt,5,old,&old);
    FlushInstructionCache(GetCurrentProcess(),tgt,5);return TRUE;}
static PBYTE gfn(const char*d,const char*n){HMODULE m=GetModuleHandleA(d);
    if(!m)m=LoadLibraryA(d);return m?(PBYTE)GetProcAddress(m,n):NULL;}

/* ============================================================
 * Shift-JIS 匹配 (エラー=83 47 83 89 81 5B, データ=83 66 81 5B 83 5E)
 * ============================================================ */
static int match_sjis(const char*h,const unsigned char*n,int nl){
    if(!h||!n||!nl)return 0;
    while(*h){int i;for(i=0;i<nl&&h[i]&&(unsigned char)h[i]==n[i];i++);
    if(i==nl)return 1;h++;}return 0;}
static const unsigned char k_er[]={0x83,0x47,0x83,0x89,0x81,0x5B};
static const unsigned char k_da[]={0x83,0x66,0x81,0x5B,0x83,0x5E};

/* ============================================================
 * MessageBox Hook
 * ============================================================ */
typedef int (WINAPI *MB_t)(HWND,LPCSTR,LPCSTR,UINT);
static PBYTE g_tmba=NULL;static int g_count=0;
static int WINAPI Hook_MBA(HWND hw,LPCSTR t,LPCSTR c,UINT u){
    UINT bt=u&0x0F;
    int err=(c&&match_sjis(c,k_er,6))||(t&&match_sjis(t,k_er,6))||(t&&match_sjis(t,k_da,6));
    if(err&&(bt==MB_YESNO||bt==MB_YESNOCANCEL||bt==MB_RETRYCANCEL)){
        g_count++;char m[100];wsprintfA(m,"[version_hook] popup #%d suppressed",g_count);
        log_write(m);return IDYES;}
    if(err&&bt==MB_ABORTRETRYIGNORE){
        g_count++;char m[100];wsprintfA(m,"[version_hook] popup #%d suppressed",g_count);
        log_write(m);return IDRETRY;}
    return ((MB_t)g_tmba)(hw,t,c,u);}

/* ============================================================
 * version.dll 转发
 * ============================================================ */
static HMODULE g_real=NULL;
static void load_real(void){if(g_real)return;WCHAR b[MAX_PATH];
    DWORD len=GetSystemDirectoryW(b,MAX_PATH);if(len==0)return;WCHAR*p=b+len;
    *p++=L'\\';*p++=L'v';*p++=L'e';*p++=L'r';*p++=L's';
    *p++=L'i';*p++=L'o';*p++=L'n';*p++=L'.';
    *p++=L'd';*p++=L'l';*p++=L'l';*p=0;
    g_real=LoadLibraryW(b);if(!g_real)g_real=LoadLibraryA("version.dll");}
static FARPROC get(const char*n){load_real();return g_real?GetProcAddress(g_real,n):NULL;}
#define X(type,name,argtypes,argnames,fail) \
    __declspec(dllexport) type WINAPI name argtypes { \
        typedef type (WINAPI *F) argtypes; \
        static F fn=NULL; if(!fn) fn=(F)get(#name); \
        if(fn) return fn argnames; return fail; }

X(DWORD,GetFileVersionInfoA,(LPCSTR a,DWORD b,DWORD c,PVOID d),(a,b,c,d),0)
X(DWORD,GetFileVersionInfoByHandle,(DWORD a,DWORD b,DWORD c,PVOID d),(a,b,c,d),0)
X(DWORD,GetFileVersionInfoExA,(DWORD a,LPCSTR b,DWORD c,DWORD d,PVOID e),(a,b,c,d,e),0)
X(DWORD,GetFileVersionInfoExW,(DWORD a,LPCWSTR b,DWORD c,DWORD d,PVOID e),(a,b,c,d,e),0)
X(BOOL,GetFileVersionInfoSizeA,(LPCSTR a,LPDWORD b),(a,b),FALSE)
X(BOOL,GetFileVersionInfoSizeExA,(DWORD a,LPCSTR b,LPDWORD c),(a,b,c),FALSE)
X(BOOL,GetFileVersionInfoSizeExW,(DWORD a,LPCWSTR b,LPDWORD c),(a,b,c),FALSE)
X(BOOL,GetFileVersionInfoSizeW,(LPCWSTR a,LPDWORD b),(a,b),FALSE)
X(BOOL,GetFileVersionInfoW,(LPCWSTR a,DWORD b,DWORD c,PVOID d),(a,b,c,d),FALSE)
X(DWORD,VerFindFileA,(DWORD a,LPCSTR b,LPCSTR c,LPCSTR d,LPSTR e,PUINT f,LPSTR g,PUINT h),(a,b,c,d,e,f,g,h),0)
X(DWORD,VerFindFileW,(DWORD a,LPCWSTR b,LPCWSTR c,LPCWSTR d,LPWSTR e,PUINT f,LPWSTR g,PUINT h),(a,b,c,d,e,f,g,h),0)
X(DWORD,VerInstallFileA,(DWORD a,LPCSTR b,LPCSTR c,LPCSTR d,LPCSTR e,LPCSTR f,LPSTR g,PUINT h),(a,b,c,d,e,f,g,h),0)
X(DWORD,VerInstallFileW,(DWORD a,LPCWSTR b,LPCWSTR c,LPCWSTR d,LPCWSTR e,LPCWSTR f,LPWSTR g,PUINT h),(a,b,c,d,e,f,g,h),0)
X(BOOL,VerLanguageNameA,(DWORD a,LPSTR b,DWORD c),(a,b,c),FALSE)
X(BOOL,VerLanguageNameW,(DWORD a,LPWSTR b,DWORD c),(a,b,c),FALSE)
X(DWORD,VerQueryValueA,(LPCVOID a,LPCSTR b,LPVOID*c,PUINT d),(a,b,c,d),0)
X(DWORD,VerQueryValueW,(LPCVOID a,LPCWSTR b,LPVOID*c,PUINT d),(a,b,c,d),0)

/* ============================================================
 * DllMain
 * ============================================================ */
BOOL WINAPI DllMain(HMODULE h,DWORD r,PVOID v){
    if(r==1){DisableThreadLibraryCalls(h);
        char lp[MAX_PATH];GetModuleFileNameA(h,lp,MAX_PATH);
        char*p=lp;for(char*s=lp;*s;s++)if(*s=='\\'||*s=='/')p=s;p[1]='\0';
        char*e=lp;while(*e)e++;
        *e++='v';*e++='h';*e++='_';*e++='l';*e++='o';*e++='g';*e++='.';
        *e++='t';*e++='x';*e++='t';*e='\0';
        g_log=CreateFileA(lp,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
        log_write("[version_hook] loaded");load_real();
        log_write("[version_hook] real version.dll loaded");
        PBYTE ma=gfn("user32.dll","MessageBoxA");
        if(ma&&hook5(ma,(PBYTE)Hook_MBA,&g_tmba))log_write("[version_hook] MessageBoxA hooked");
        else log_write("[version_hook] MessageBoxA hook FAILED");
    }else if(r==0){
        char m[100];wsprintfA(m,"[version_hook] unloaded, total: %d",g_count);
        log_write(m);if(g_log!=INVALID_HANDLE_VALUE)CloseHandle(g_log);}
    return TRUE;
}
